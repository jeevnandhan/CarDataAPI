package com.kickoffHandsOn.wings1_t4_car_data_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Wings1T4CarDataApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Wings1T4CarDataApiApplication.class, args);
	}

}
