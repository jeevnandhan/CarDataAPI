package com.kickoffHandsOn.wings1_t4_car_data_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Wings1T4CarDataApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
